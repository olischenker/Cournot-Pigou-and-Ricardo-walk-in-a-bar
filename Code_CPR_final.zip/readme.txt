This file contains the GAMS code of the model used in 

Title: "Cournot, Pigou, and Ricardo walk in a bar -- Unilateral environmental policy and leakage with market power and firm heterogeneity."

Authors: Claudio Baccianti (Tilburg University) and Oliver Schenker (Frankfurt School of Finance & Management)

This version: 2021-11-04

Figures and tables in the paper:
- Figure 2 shows results stored in DECOMP
- Tables 3 and 4 show results in CHANGE_OPT, all iterations
- Tables 5 and 6 show results in CHANGE_CBAM, iteration ITR_AA4
